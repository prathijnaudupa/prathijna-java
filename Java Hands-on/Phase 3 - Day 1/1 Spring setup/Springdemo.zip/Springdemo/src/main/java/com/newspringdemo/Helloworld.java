package com.newspringdemo;

public class Helloworld {
	public void print() {
		System.out.println("welcome");
	}

}

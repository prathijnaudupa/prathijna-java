import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class getpost extends HttpServlet
{
protected void doGet(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException
{
response.setContentType("text/html");
PrintWriter out=response.getWriter();
String s=request.getParameter("degree");
out.println("<h4>Its from get method</h4><br />");
out.println("<b><i>Contents attaced to URL</i></b><br />");
out.println("<b>Selected degree is: <b> "+s);
out.close();
}
protected void doPost(HttpServletRequest request, HttpServletResponse response)
throws ServletException, IOException
{
response.setContentType("text/html");
PrintWriter out=response.getWriter();
String s=request.getParameter("lang");
out.println("<h4>Its from post method</h4><br />");
out.println("<b><i>Contents are not attached to URL</i></b><br />");
out.println("<b>Selected Programming language is: <b> "+s);
out.close();
}
}
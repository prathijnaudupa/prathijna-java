package com.eccomerce.DemoHib;

public @interface Tr {

}

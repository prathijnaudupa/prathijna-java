package com.eccomerce.DemoHib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import jakarta.transaction.HeuristicMixedException;
import jakarta.transaction.HeuristicRollbackException;
import jakarta.transaction.RollbackException;
import jakarta.transaction.SystemException;
import jakarta.transaction.Transaction;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws SecurityException, IllegalStateException, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException
    {
    	NewClass nc = new NewClass();
    	
    	nc.setAid(101);
    	nc.setAname("prathijna");
    	nc.setColor("Pink");
    	
    	
    	Configuration conn = new Configuration().configure().addAnnotatedClass(NewClass.class);
    	
    	SessionFactory sf = conn.buildSessionFactory();
    	
    	Session session = sf.openSession();
    	
    	org.hibernate.Transaction tx = session.beginTransaction();
    	
    	session.save(nc);
    	tx.commit();
    }
}
